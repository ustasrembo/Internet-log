package com.example.internetlog

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private val prefs by lazy { getSharedPreferences("monitor", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 24)
        }
        val title = TextView(this).apply { text = "Internet Log"; textSize = 28f }
        status = TextView(this).apply { textSize = 18f; setPadding(0, 24, 0, 24) }
        val start = Button(this).apply { text = "Запустить мониторинг" }
        val stop = Button(this).apply { text = "Остановить мониторинг" }
        val refresh = Button(this).apply { text = "Обновить журнал" }
        val export = Button(this).apply { text = "Экспорт CSV" }
        logView = TextView(this).apply { textSize = 13f; setPadding(0, 16, 0, 16) }
        layout.addView(title); layout.addView(status)
        layout.addView(start); layout.addView(stop); layout.addView(refresh); layout.addView(export)
        val scroll = ScrollView(this).apply { addView(logView) }
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)

        start.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            }
            ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java).setAction("START"))
            prefs.edit().putBoolean("running", true).apply()
            update()
        }
        stop.setOnClickListener {
            stopService(Intent(this, MonitorService::class.java))
            prefs.edit().putBoolean("running", false).apply()
            update()
        }
        refresh.setOnClickListener { update() }
        export.setOnClickListener { shareCsv() }
        update()
    }

    override fun onResume() { super.onResume(); update() }

    private fun update() {
        status.text = if (prefs.getBoolean("running", false)) "Мониторинг включён • интервал 5 сек."
                      else "Мониторинг остановлен"
        val file = File(filesDir, "internet-log.csv")
        logView.text = if (file.exists()) file.readText().takeLast(12000).ifBlank { "Событий пока нет." }
                       else "Событий пока нет."
    }

    private fun shareCsv() {
        val file = File(filesDir, "internet-log.csv")
        if (!file.exists()) { Toast.makeText(this, "Журнал пока пуст", Toast.LENGTH_SHORT).show(); return }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_TEXT, file.readText())
        }
        startActivity(Intent.createChooser(intent, "Отправить журнал CSV"))
    }
}
