package com.example.internetlog

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonitorService : Service() {
    private val prefs by lazy { getSharedPreferences("monitor", MODE_PRIVATE) }
    @Volatile private var active = false
    private var wasOnline: Boolean? = null
    private var downSince = 0L
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification("Мониторинг интернета • проверка каждые 5 секунд"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!active) {
            active = true
            prefs.edit().putBoolean("running", true).apply()
            Thread { monitorLoop() }.start()
        }
        return START_STICKY
    }

    private fun monitorLoop() {
        while (active) {
            val online = hasInternet()
            val now = System.currentTimeMillis()
            if (wasOnline == null) {
                wasOnline = online
                if (!online) {
                    downSince = now
                    log("ОБРЫВ", "Интернет недоступен при запуске")
                } else log("СТАРТ", "Интернет доступен")
            } else if (wasOnline == true && !online) {
                downSince = now
                log("ОБРЫВ", "Интернет пропал")
                wasOnline = false
            } else if (wasOnline == false && online) {
                val seconds = ((now - downSince) / 1000.0)
                log("ВОССТАНОВЛЕН", "Интернет восстановлен; простой: ${"%.1f".format(Locale.US, seconds)} сек.")
                wasOnline = true
            }
            try { Thread.sleep(5000) } catch (_: InterruptedException) { }
        }
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        val hasTransport = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        if (!hasTransport || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        return try {
            val conn = URL("https://connectivitycheck.gstatic.com/generate_204").openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.instanceFollowRedirects = false
            conn.requestMethod = "GET"
            conn.connect()
            val ok = conn.responseCode == 204
            conn.disconnect()
            ok
        } catch (_: Exception) { false }
    }

    private fun log(event: String, detail: String) {
        val file = File(filesDir, "internet-log.csv")
        val fresh = !file.exists()
        file.appendText((if (fresh) "Дата и время;Событие;Описание\n" else "") +
            "${dateFmt.format(Date())};$event;$detail\n")
        updateNotification(if (event == "ОБРЫВ") "Интернет недоступен" else "Интернет доступен")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("internet_log", "Internet Log", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "internet_log") else Notification.Builder(this)
        return builder.setContentTitle("Internet Log").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim).setOngoing(true).build()
    }
    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(7, notification(text))
    }

    override fun onDestroy() {
        active = false
        prefs.edit().putBoolean("running", false).apply()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
